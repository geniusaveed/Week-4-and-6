Advanced Topics in Cybersecurity - Boolean MPC and Countermeasures for AES
Submission by Syed Aveed Ali

Contents
--------
report/report.pdf     Full write-up: Exercises 1, 2*, 3 (all subparts incl. the
                       starred ones), and 4*.
report/report.tex     LaTeX source of the above.
code/GF256MPC.py       Completed MPC library: isw_multiply, Shared_AddRoundKey
                       (+ two realistic alternatives), the a^2+a*b gadget, and a
                       self-test suite at the bottom (run: python3 GF256MPC.py).
code/sim_masking.py    Simulations/attacks for Exercise 2 (insecure 2PC
                       multiplication) and Exercise 4 (three masked table
                       look-up scenarios). Run: python3 sim_masking.py --help
code/run_experiments.py
                       Reproduces every figure/number quoted in the report
                       (run: python3 run_experiments.py).
results/               Generated figures (PNG) and results.json.

Requirements: Python 3, numpy, galois, matplotlib.
  pip install numpy galois matplotlib

Note on the LLM exercise (3.6): only exercise 3.6 made use of an LLM, as
required by the lab sheet; all starred exercises (2, 3.4, 3.5, 3.6, 4) were
otherwise solved without LLM assistance for the core cryptographic content.
