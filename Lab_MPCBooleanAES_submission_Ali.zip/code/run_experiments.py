"""
Produces the figures and numbers used in the report (Exercises 2 and 4).
Writes PNGs and a small JSON of results into ../results/.
Runtime: ~1-2 minutes on a single core.
"""
import json
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import sim_masking as S

OUT = os.path.join(os.path.dirname(__file__), "..", "results")
os.makedirs(OUT, exist_ok=True)
RESULTS = {}


# ----------------------------------------------------------------------------
# Exercise 2: success rate / rank of the key vs number of traces, per key byte
# ----------------------------------------------------------------------------
def ex2_experiment():
    Ns = [200, 500, 1000, 2000, 3000, 5000, 8000, 12000]
    reps = 15
    rng = np.random.default_rng(0)
    # (a) fixed key, varying N -> success rate and mean rank (c1+c2 distinguisher)
    key_fixed = 0x2B
    succ, mean_rank = [], []
    for N in Ns:
        ranks = []
        for r in range(reps):
            x = S.rand_bytes(rng, N)
            tr = S.simulate_2pc_traces(x, key_fixed, 1.0, rng)
            sc = S.zero_value_scores(x, tr[:, 4] + tr[:, 5])
            ranks.append(S.rank_of(sc, key_fixed))
        ranks = np.array(ranks)
        succ.append(float(np.mean(ranks == 1)))
        mean_rank.append(float(np.mean(ranks)))
    RESULTS["ex2_Ns"] = Ns
    RESULTS["ex2_success_rate"] = succ
    RESULTS["ex2_mean_rank"] = mean_rank

    plt.figure(figsize=(5, 3.5))
    plt.plot(Ns, succ, "o-")
    plt.axhline(0.9, color="gray", ls="--", lw=0.8)
    plt.xlabel("number of traces N")
    plt.ylabel("P(rank 1) over 15 runs")
    plt.title("Exercise 2: zero-value attack on c1+c2")
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "ex2_success_vs_N.png"), dpi=140)
    plt.close()

    # (b) are all key bytes equally easy? fix N, vary key over all 256 values
    N_fix = 3000
    ranks_per_key = []
    for k in range(256):
        x = S.rand_bytes(rng, N_fix)
        tr = S.simulate_2pc_traces(x, k, 1.0, rng)
        sc = S.zero_value_scores(x, tr[:, 4] + tr[:, 5])
        ranks_per_key.append(S.rank_of(sc, k))
    ranks_per_key = np.array(ranks_per_key)
    RESULTS["ex2_rank_per_key_N3000"] = ranks_per_key.tolist()
    RESULTS["ex2_rank_per_key_summary"] = {
        "mean": float(ranks_per_key.mean()), "max": int(ranks_per_key.max()),
        "frac_rank1": float(np.mean(ranks_per_key == 1)),
        "worst_keys": [int(k) for k in np.argsort(-ranks_per_key)[:5]],
    }
    plt.figure(figsize=(5, 3.5))
    plt.plot(range(256), ranks_per_key, ".", ms=3)
    plt.xlabel("key byte value")
    plt.ylabel("rank of correct key (N=3000)")
    plt.title("Exercise 2: rank vs. key byte value")
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "ex2_rank_vs_keybyte.png"), dpi=140)
    plt.close()
    print("Exercise 2 done.")


# ----------------------------------------------------------------------------
# Exercise 4: success rate vs N, and "N for correct key in top-3" per scenario
# ----------------------------------------------------------------------------
def top3_hit(scores, true_idx):
    return S.rank_of(scores, true_idx) <= 3


def ex4_experiment():
    Ns = [300, 500, 800, 1200, 2000, 3000, 5000, 8000]
    reps = 12
    rng = np.random.default_rng(1)
    succ_s1, succ_s2, succ_s3diff, succ_s3pair = [], [], [], []
    for N in Ns:
        h1 = h2 = h3d = h3p = 0
        for r in range(reps):
            k0, k1 = int(rng.integers(0, 256)), int(rng.integers(0, 256))
            x0, x1 = S.rand_bytes(rng, N), S.rand_bytes(rng, N)
            # S1
            tr = S.gen_s1(x0, k0, 1.0, rng)
            h1 += top3_hit(S.attack_s1(x0, tr), k0)
            # S2 (combined distinguisher: sum of both sub-attacks)
            tr = S.gen_s2(x0, k0, 1.0, rng)
            _, _, both = S.attack_s2(x0, tr)
            h2 += top3_hit(both, k0)
            # S3: masks never leak -> best achievable is the key DIFFERENCE (single trace
            # set), and the joint (k0,k1) pair attack using two state bytes' traces
            tr = S.gen_s3(x0, x1, k0, k1, 1.0, rng)
            h3d += top3_hit(S.attack_s3_diff(x0, x1, tr), k0 ^ k1)
            sc_pair = S.s3_pair_scores(x0, x1, tr, [N])[N]
            h3p += top3_hit(sc_pair, k0 * 256 + k1)
        succ_s1.append(h1 / reps); succ_s2.append(h2 / reps)
        succ_s3diff.append(h3d / reps); succ_s3pair.append(h3p / reps)

    RESULTS["ex4_Ns"] = Ns
    RESULTS["ex4_success_s1"] = succ_s1
    RESULTS["ex4_success_s2"] = succ_s2
    RESULTS["ex4_success_s3_diff"] = succ_s3diff
    RESULTS["ex4_success_s3_pair"] = succ_s3pair

    def first_N_above(Ns, succ, thresh=0.9):
        for n, s in zip(Ns, succ):
            if s >= thresh:
                return n
        return None

    RESULTS["ex4_N_for_90pct_top3"] = {
        "scenario1_same_mask": first_N_above(Ns, succ_s1),
        "scenario2_indep_masks_leak": first_N_above(Ns, succ_s2),
        "scenario3_key_difference_only": first_N_above(Ns, succ_s3diff),
        "scenario3_joint_pair_attack": first_N_above(Ns, succ_s3pair),
    }

    plt.figure(figsize=(6, 4))
    plt.plot(Ns, succ_s1, "o-", label="S1: identical in/out mask")
    plt.plot(Ns, succ_s2, "s-", label="S2: indep. masks, both leak")
    plt.plot(Ns, succ_s3diff, "^-", label="S3: indep., masks hidden (key diff. only)")
    plt.plot(Ns, succ_s3pair, "d-", label="S3: indep., masks hidden (joint k0,k1)")
    plt.axhline(0.9, color="gray", ls="--", lw=0.8)
    plt.xlabel("number of traces N")
    plt.ylabel("P(correct key/diff in top-3), 12 runs")
    plt.title("Exercise 4: masked table look-up attacks")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(os.path.join(OUT, "ex4_success_vs_N.png"), dpi=140)
    plt.close()
    print("Exercise 4 done.")


if __name__ == "__main__":
    ex2_experiment()
    ex4_experiment()
    with open(os.path.join(OUT, "results.json"), "w") as f:
        json.dump(RESULTS, f, indent=2)
    print("Wrote results.json and figures to", os.path.abspath(OUT))
