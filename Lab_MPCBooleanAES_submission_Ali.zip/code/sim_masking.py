"""
Advanced Topics in Cybersecurity -- Lab "Boolean MPC and Countermeasures for AES"

Simulations for
  * Exercise 2: attack on the insecure (2,2) shared GF(2^8) multiplication
                (diagonal / off-diagonal summation of the partial products)
  * Exercise 4: attacks on "efficient" (2,2) masked table look-ups
                scenario 1: input/output leak, identical input & output mask
                scenario 2: different masks, both masks leak
                scenario 3: different masks, masks do not leak, but the same
                            masks are re-used for several state bytes

The original function `sim_attack_masking` of the handout is kept (two off-by-one
slips fixed, see comments).  Everything else is self contained: if the course module
`leak_sim.simulate` is not importable, an equivalent S-box / Hamming-weight table is
built locally.  Run `python sim_masking.py --help` for the quick demos; the heavy
experiments (success curves, figures, tables of the report) are in run_experiments.py.

Leakage model used throughout: Hamming weight of every simulated intermediate byte
plus independent Gaussian noise N(0, sigma^2), exactly as in the handout (sigma = 1).
"""
import argparse
import numpy as np

# ----------------------------------------------------------------------------------
# Tables: GF(2^8) (AES polynomial 0x11B), S-box, Hamming weight
# ----------------------------------------------------------------------------------
def _build_gf_tables():
    exp = np.zeros(510, dtype=np.uint8)
    log = np.zeros(256, dtype=np.int64)
    v = 1
    for i in range(255):
        exp[i] = v
        log[v] = i
        # multiply by the generator 3 = x + 1
        v2 = (v << 1) ^ (0x11B if v & 0x80 else 0)
        v = (v2 ^ v) & 0xFF
    exp[255:510] = exp[0:255]
    a = np.arange(256)
    mult = exp[(log[:, None] + log[None, :])]
    mult[0, :] = 0
    mult[:, 0] = 0
    inv = np.zeros(256, dtype=np.uint8)
    inv[1:] = exp[255 - log[1:]]
    return mult.astype(np.uint8), inv, exp, log


MUL, INV, _EXP, _LOG = _build_gf_tables()          # MUL[a, b] = a*b in GF(2^8)


def _build_sbox():
    sb = np.zeros(256, dtype=np.uint8)
    for x in range(256):
        b = int(INV[x])
        s = b
        for sh in range(1, 5):                       # b ^ rotl(b,1..4) ^ 0x63
            s ^= ((b << sh) | (b >> (8 - sh))) & 0xFF
        sb[x] = s ^ 0x63
    return sb


SBOX = _build_sbox()
assert SBOX[0x00] == 0x63 and SBOX[0x01] == 0x7C and SBOX[0x53] == 0xED   # FIPS-197
HW8 = np.array([bin(i).count("1") for i in range(256)], dtype=np.int64)
HW8F = HW8.astype(np.float32)
SQ = MUL[np.arange(256), np.arange(256)]                                  # x -> x^2
GUESS = np.arange(256, dtype=np.uint8)

try:                                                  # course environment, if present
    import leak_sim.simulate as sim
except Exception:                                      # pragma: no cover
    class _LocalSim:
        sbox = staticmethod(lambda v: SBOX[np.asarray(v, dtype=np.int64) & 0xFF])
        HW8 = HW8
    sim = _LocalSim()


# ----------------------------------------------------------------------------------
# Generic helpers
# ----------------------------------------------------------------------------------
def hw_leak(values, sigma, rng):
    """Hamming-weight leakage + Gaussian noise (one sample per value)."""
    return HW8[values] + rng.normal(0.0, sigma, size=np.shape(values))


def rand_bytes(rng, n):
    return rng.integers(0, 256, size=n, dtype=np.uint8)


def pearson_rows(H, p):
    """Pearson correlation of every row of H (G x N) with the vector p (N)."""
    H = H.astype(np.float64)
    Hc = H - H.mean(axis=1, keepdims=True)
    pc = p - p.mean()
    num = Hc @ pc
    den = np.sqrt((Hc ** 2).sum(axis=1) * (pc ** 2).sum())
    with np.errstate(invalid="ignore", divide="ignore"):
        r = num / den
    return np.nan_to_num(r)


def rank_of(scores, true_idx):
    """Rank (1 = best) of true_idx when LOWER score is better (the expected sign of the
    correlation for centred-product leakage and for the zero-value test is negative).
    Ties are counted against the attacker (pessimistic)."""
    s = np.asarray(scores).ravel()
    better = np.sum(s <= s[true_idx]) - 1
    return int(better) + 1


# ----------------------------------------------------------------------------------
# Exercise 2: insecure (2,2) multiplication  c1 = a1b1 + a2b2,  c2 = a2b1 + a1b2
# ----------------------------------------------------------------------------------
LABELS_2PC = ["v1", "v2", "v3", "v4", "c1", "c2"]


def simulate_2pc_traces(x, key, sigma, rng):
    """Power traces (N x 6) leaking on v1..v4, c1, c2 of masked_multiplication(a, b)
    with a = x ^ key, b = a^2 (first multiplication of the AES S-box inversion).
    Fresh random sharings of a and b are drawn for every execution."""
    n = len(x)
    a = x ^ np.uint8(key)
    b = SQ[a]
    a1, b1 = rand_bytes(rng, n), rand_bytes(rng, n)
    a2, b2 = a ^ a1, b ^ b1
    v1, v2, v3, v4 = MUL[a1, b1], MUL[a1, b2], MUL[a2, b1], MUL[a2, b2]
    c1, c2 = v1 ^ v4, v3 ^ v2                         # diagonal / off-diagonal sums
    inter = np.stack([v1, v2, v3, v4, c1, c2], axis=1)
    return hw_leak(inter, sigma, rng)


def zero_value_scores(x, L):
    """Zero-value distinguisher.  For every key guess g: Pearson correlation between
    the indicator [x ^ g == 0] (i.e. 'a = 0') and the leakage L.  Computed in closed
    form from per-input counts (no 256 x N matrix needed).  Correct key => strongly
    NEGATIVE correlation (c1 = c2 = 0 whenever a = 0, uniform otherwise)."""
    n = len(x)
    cnt = np.bincount(x, minlength=256).astype(np.float64)
    sg = np.bincount(x, weights=L, minlength=256)
    sl, sll = L.sum(), (L ** 2).sum()
    num = n * sg - cnt * sl
    den = np.sqrt(np.maximum((n * cnt - cnt ** 2) * (n * sll - sl ** 2), 0))
    with np.errstate(invalid="ignore", divide="ignore"):
        r = num / den
    return np.nan_to_num(r)                          # guesses never observed -> 0


def cpa_scores_hw(x, traces, model="sbox"):
    """Ordinary first-order CPA (HW model) as used in the handout, for comparison.
    Returns correlation matrix (256 guesses x samples)."""
    tbl = {"sbox": SBOX, "xor": np.arange(256, dtype=np.uint8)}[model]
    H = HW8F[tbl[x[None, :] ^ GUESS[:, None]]]
    out = np.zeros((256, traces.shape[1]))
    for j in range(traces.shape[1]):
        out[:, j] = pearson_rows(H, traces[:, j])
    return out


def sim_2PC_multiplication(num_traces=3000, sigma=1.0, key=None, seed=None, verbose=True):
    """Exercise 2: simulate traces of the insecure multiplication and attack them.
    Returns a dict with the recovered key and ranks."""
    rng = np.random.default_rng(seed)
    key = int(rng.integers(0, 256)) if key is None else int(key)
    x = rand_bytes(rng, num_traces)
    tr = simulate_2pc_traces(x, key, sigma, rng)
    res = {"key": key, "N": num_traces, "sigma": sigma}
    # (a) first-order CPA with the usual model: fails (the sharing hides HW(S(x^k)))
    cpa = cpa_scores_hw(x, tr, "sbox")
    res["cpa_best_guess"] = int(np.unravel_index(np.argmax(np.abs(cpa)), cpa.shape)[0])
    res["cpa_max_abs_corr"] = float(np.abs(cpa).max())
    # (b) zero-value attack on each sample and on c1 + c2
    for name, L in [(l, tr[:, i]) for i, l in enumerate(LABELS_2PC)] + [("c1+c2", tr[:, 4] + tr[:, 5])]:
        sc = zero_value_scores(x, L)
        res[name] = {"guess": int(np.argmin(sc)), "min_corr": float(sc.min()),
                     "rank_of_key": rank_of(sc, key)}
    if verbose:
        print(f"[2PC] secret key byte = {key:#04x}, N = {num_traces}, sigma = {sigma}")
        print(f"  first-order CPA (HW of S-box output) : best guess {res['cpa_best_guess']:#04x}, "
              f"max|rho| = {res['cpa_max_abs_corr']:.3f}  -> {'correct (by luck)' if res['cpa_best_guess']==key else 'FAILS'}")
        for name in LABELS_2PC + ["c1+c2"]:
            r = res[name]
            print(f"  zero-value attack on {name:5s}: best guess {r['guess']:#04x}, "
                  f"rho = {r['min_corr']:+.3f}, rank of true key = {r['rank_of_key']}")
    return res


# ----------------------------------------------------------------------------------
# Exercise 4: masked table look-ups
#   a = x ^ k (S-box input), masked look-up  u = a ^ m_in  ->  v = S(a) ^ m_out
#   centred product of two leakage samples  P = (L_i - 4)(L_j - 4)  (E[HW(uniform)] = 4)
#   For two byte-values u, v with u ^ v = d (both uniform):  E[P | d] = 2 - HW(d)/2
#   => P correlates (negatively, linearly) with HW(d); attack d = f(x ^ guess).
# ----------------------------------------------------------------------------------
def centred_product(Li, Lj):
    return (Li - 4.0) * (Lj - 4.0)


def gen_s1(x, k, sigma, rng):
    """Scenario 1: one mask m for input and output.  Samples: [u=a^m, v=S(a)^m, noise]."""
    a = x ^ np.uint8(k)
    m = rand_bytes(rng, len(x))
    inter = np.stack([a ^ m, SBOX[a] ^ m], axis=1)
    tr = hw_leak(inter, sigma, rng)
    return np.concatenate([tr, rng.normal(1.0, sigma, size=(len(x), 1))], axis=1)


def gen_s2(x, k, sigma, rng):
    """Scenario 2: independent masks, both masks leak.
    Samples: [u=a^m_in, m_in, v=S(a)^m_out, m_out, noise]."""
    a = x ^ np.uint8(k)
    m_in, m_out = rand_bytes(rng, len(x)), rand_bytes(rng, len(x))
    inter = np.stack([a ^ m_in, m_in, SBOX[a] ^ m_out, m_out], axis=1)
    tr = hw_leak(inter, sigma, rng)
    return np.concatenate([tr, rng.normal(1.0, sigma, size=(len(x), 1))], axis=1)


def gen_s3(x0, x1, k0, k1, sigma, rng):
    """Scenario 3: independent in/out masks that never leak, but the SAME (m_in, m_out)
    protect two state bytes.  Samples: [u0, v0, u1, v1, noise]."""
    n = len(x0)
    a0, a1 = x0 ^ np.uint8(k0), x1 ^ np.uint8(k1)
    m_in, m_out = rand_bytes(rng, n), rand_bytes(rng, n)
    inter = np.stack([a0 ^ m_in, SBOX[a0] ^ m_out, a1 ^ m_in, SBOX[a1] ^ m_out], axis=1)
    tr = hw_leak(inter, sigma, rng)
    return np.concatenate([tr, rng.normal(1.0, sigma, size=(n, 1))], axis=1)


# hypothesis models: byte function of a = x ^ guess whose Hamming weight is predicted
MODEL_TABLES = {
    "a^S(a)": (np.arange(256, dtype=np.uint8) ^ SBOX),    # scenario 1
    "S(a)":   SBOX,                                       # scenario 2 (output side)
    "a":      np.arange(256, dtype=np.uint8),             # scenario 2 (input side)
}


def attack_256(x, P, model):
    """Correlation of the product trace P with HW(model(x ^ g)) for all 256 guesses."""
    H = HW8F[MODEL_TABLES[model][x[None, :] ^ GUESS[:, None]]]
    return pearson_rows(H, P)


def attack_s1(x, tr):
    return attack_256(x, centred_product(tr[:, 0], tr[:, 1]), "a^S(a)")


def attack_s2(x, tr):
    """Returns the score vectors of the output-side attack, input-side attack, and their sum."""
    s_out = attack_256(x, centred_product(tr[:, 2], tr[:, 3]), "S(a)")
    s_in = attack_256(x, centred_product(tr[:, 0], tr[:, 1]), "a")
    return s_out, s_in, s_out + s_in


def attack_s3_diff(x0, x1, tr):
    """Input side: u0 ^ u1 = (x0 ^ x1) ^ (k0 ^ k1)  -> recovers the key DIFFERENCE only."""
    P = centred_product(tr[:, 0], tr[:, 2])
    return attack_256(x0 ^ x1, P, "a")


def s3_pair_scores(x0, x1, tr, checkpoints):
    """Joint attack on (k0, k1): 65536 hypotheses, centred product of the two OUTPUT
    leakages v0, v1 against HW(S(x0^g0) ^ S(x1^g1)).  Running sums over blocks give the
    correlation matrix (256 x 256) at every checkpoint N without recomputation."""
    N = len(x0)
    P = centred_product(tr[:, 1], tr[:, 3]).astype(np.float32)
    A = SBOX[x0[None, :] ^ GUESS[:, None]]
    B = SBOX[x1[None, :] ^ GUESS[:, None]]
    sH = np.zeros((256, 256)); sHH = np.zeros((256, 256)); sHP = np.zeros((256, 256))
    sP = sPP = 0.0
    out, prev = {}, 0
    for cp in checkpoints:
        Pb, Bb = P[prev:cp], B[:, prev:cp]
        for g0 in range(256):
            Hf = HW8F[Bb ^ A[g0, prev:cp][None, :]]
            sH[g0] += Hf.sum(axis=1)
            sHH[g0] += np.einsum("ij,ij->i", Hf, Hf)
            sHP[g0] += Hf @ Pb
        sP += float(Pb.sum()); sPP += float((Pb.astype(np.float64) ** 2).sum())
        prev = cp
        n = cp
        num = n * sHP - sH * sP
        den = np.sqrt(np.maximum((n * sHH - sH ** 2) * (n * sPP - sP ** 2), 0))
        with np.errstate(invalid="ignore", divide="ignore"):
            out[cp] = np.nan_to_num(num / den)
    return out


# ----------------------------------------------------------------------------------
# Original handout code (kept; two off-by-one slips fixed)
# ----------------------------------------------------------------------------------
def byte_correlation(inputs, traces):
    # iterate over all the 256 values that a key byte can take
    trace_len = traces.shape[1]
    dist = np.zeros((256, trace_len))
    for key_guess in range(256):                      # handout: range(255) skipped guess 255
        ark = np.bitwise_xor(inputs, key_guess)
        sb = sim.sbox(ark)
        pred_leak = sim.HW8[sb]
        chunksize = 50
        for chunk in range(0, trace_len, chunksize):
            cor = np.corrcoef(pred_leak.T, traces[:, chunk:chunk + chunksize], rowvar=False)
            dist[key_guess, chunk:chunk + chunksize] = cor[0, 1:]
    return dist


def sim_attack_masking(num_inputs):
    """Handout simulation: (2,2) shared S-box OUTPUT, leakage on both shares."""
    rng = np.random.default_rng()
    inputs = rng.integers(low=0, high=256, size=(num_inputs, 1))
    skey = rng.integers(low=0, high=256, size=1)
    print(f"[+] Secret key is supposed to be {skey}")
    ark = np.bitwise_xor(inputs, skey)
    sb = sim.sbox(ark)
    sb_share = rng.integers(low=0, high=256, size=(num_inputs, 1))    # handout: high=255
    sb_share = np.concatenate((sb_share, np.bitwise_xor(sb_share, sb)), axis=1)
    traces = sim.HW8[sb_share] + rng.normal(0, 1, size=(num_inputs, 2))
    traces = np.concatenate((traces, rng.normal(1, 1, size=(num_inputs, 1))), axis=1)
    traces = traces - np.mean(traces, axis=0)
    prod_traces = np.zeros((num_inputs, 3))
    prod_traces[:, 0] = traces[:, 0] * traces[:, 1]
    prod_traces[:, 1] = traces[:, 0] * traces[:, 2]
    prod_traces[:, 2] = traces[:, 1] * traces[:, 2]
    inp = np.reshape(inputs, (1, -1))
    pcor_vals = byte_correlation(inp, prod_traces)
    key_ind = np.unravel_index(np.argmax(np.absolute(pcor_vals)), pcor_vals.shape)
    print(f"[+] Highest correlation occurs for key {key_ind[0]} at time index {key_ind[1]}.")
    if skey == key_ind[0]:
        print("Yipee!")


# ----------------------------------------------------------------------------------
# Quick demos for Exercise 4
# ----------------------------------------------------------------------------------
def demo_scenarios(N=2000, sigma=1.0, seed=1):
    rng = np.random.default_rng(seed)
    k0, k1 = int(rng.integers(0, 256)), int(rng.integers(0, 256))
    x0, x1 = rand_bytes(rng, N), rand_bytes(rng, N)
    print(f"keys: k0={k0:#04x}  k1={k1:#04x}   N={N}  sigma={sigma}")
    tr = gen_s1(x0, k0, sigma, rng)
    s = attack_s1(x0, tr)
    print(f"[S1] same mask in/out        : best {int(np.argmin(s)):#04x}  rank of k0 = {rank_of(s, k0)}")
    tr = gen_s2(x0, k0, sigma, rng)
    for name, s in zip(["out-pair HW(S(a))", "in-pair HW(a)", "both"], attack_s2(x0, tr)):
        print(f"[S2] masks leak, {name:18s}: best {int(np.argmin(s)):#04x}  rank of k0 = {rank_of(s, k0)}")
    tr = gen_s3(x0, x1, k0, k1, sigma, rng)
    s = attack_s3_diff(x0, x1, tr)
    print(f"[S3] shared masks, key difference k0^k1 = {k0 ^ k1:#04x}: rank = {rank_of(s, k0 ^ k1)}")
    sc = s3_pair_scores(x0, x1, tr, [N])[N]
    print(f"[S3] shared masks, pair attack (65536 hyp.): rank of (k0,k1) = {rank_of(sc, k0 * 256 + k1)}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("what", nargs="?", default="all", choices=["all", "ex2", "ex4", "handout"])
    ap.add_argument("-N", type=int, default=3000, help="number of traces")
    ap.add_argument("--sigma", type=float, default=1.0)
    ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    if a.what in ("all", "ex2"):
        sim_2PC_multiplication(a.N, a.sigma, seed=a.seed)
    if a.what in ("all", "ex4"):
        demo_scenarios(a.N, a.sigma, a.seed)
    if a.what in ("all", "handout"):
        sim_attack_masking(500)
