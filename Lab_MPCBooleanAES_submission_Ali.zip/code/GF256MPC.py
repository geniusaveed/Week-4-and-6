"""
Additive secret sharing over GF(2^8) (specialised to the AES field).
- Field reduction polynomial (for reference): x^8 + x^4 + x^3 + x + 1 (0x11B)
- This module implements additive sharing supporting the addition of shares, addition with
  constant, as well as multiplication of shares.
"""

from typing import List, Sequence
import secrets

import galois

class GF256MPC:
    """
    Boolean secret sharing over GF(2^8).
    Values are single bytes only, we expect an integer representation.

    Functions:
      - share(secret, parties) -> list of shares
      - reconstruct(shares) -> secret
      - add(shares_x, shares_y) -> elementwise addition (XOR) of shares
      - add_constant(shares, public_constant) -> add a public constant to a shared secret
      - multiply(shares_x, shares_y) -> ISW multiplication of input shares
    """
    AES_POLY = 0x11B

    @staticmethod
    def _is_byte_value(x) -> bool:
        return isinstance(x, int) and 0 <= x <= 0xFF

    @staticmethod
    def gf256_mul(a: int, b: int) -> int:
        """
        Multiply two GF(2^8) elements modulo 0x11B.
        Inputs and output are ints 0..255.
        The multiplication proceeds by simply running through the bits of b,
        and adding in a if the corresponding bit of b is one (so term wise
        multiplication).
        This is not what typically happens in an embedded device, but it suffices
        for our purposes here.
        """

        res = 0
        for _ in range(8):
            if b & 1:
                res ^= a
            msb = a & 0x80
            a = ((a << 1) & 0xFF)
            if msb:
                a ^= (GF256MPC.AES_POLY & 0xFF)
            b >>= 1
        return res & 0xFF

    @staticmethod
    def share(secret: int, n: int) -> List[int]:
        """
        Create n additive shares of `secret` (single byte represented as integer 0...255).
        Shares are hence also integers 0..255.


        Security note: uses cryptographically secure randomness (secrets).
        """
        if n < 2:
            raise ValueError("Number of parties must be >= 2")

        # integer (single byte)
        if GF256MPC._is_byte_value(secret):
            shares = [secrets.randbits(8) for _ in range(n - 1)]
            last = secret
            for s in shares:
                last ^= s
            shares.append(last & 0xFF)
            return shares


        raise TypeError("Input must be an int (0..255)")

    @staticmethod
    def reconstruct(shares: Sequence[int]) -> int:
        """
        Reconstruct an additive-shared secret.
        Accepts either a sequence of ints (single-byte shares) or sequence of bytes (byte-string shares).
        """
        if not shares:
            raise ValueError("Empty share list")

        first = shares[0]
        if GF256MPC._is_byte_value(first):
            # all must be ints 0..255
            result = 0
            for s in shares:
                if not GF256MPC._is_byte_value(s):
                    raise TypeError("All shares must be ints in 0..255")
                result ^= s
            return result

        raise TypeError("Shares must be all ints")

    @staticmethod
    def add(a_shares: Sequence[int],
            b_shares: Sequence[int]) -> List[int]:
        """
        Locally add two shared values by XORing each party's local share:
          c_i = a_i ^ b_i
        Returns a new list of shares representing the sum.
        """
        if len(a_shares) != len(b_shares):
            raise ValueError("Share lists must have equal length")
        n = len(a_shares)
        # integer shares
        if all(GF256MPC._is_byte_value(s) for s in a_shares) and all(GF256MPC._is_byte_value(s) for s in b_shares):
            return [ (a_shares[i] ^ b_shares[i]) for i in range(n) ]


        raise TypeError("Both share lists must be all ints or all byte-strings")

    @staticmethod
    def add_constant(shares: List[int],
                     constant: int,
                     target_party: int = 0) -> List[int]:
        """
        Add a public constant (int 0..255 or bytes) to a shared secret.
        We add the constant to a single party's share (default party 0) so reconstruction yields correct value
        while preserving secrecy.
        """
        if not shares:
            raise ValueError("Empty shares")

        n = len(shares)
        if not (0 <= target_party < n):
            raise IndexError("target_party out of range")

        out = list(shares)  # shallow copy


        if GF256MPC._is_byte_value(shares[0]):
            if not GF256MPC._is_byte_value(constant):
                raise TypeError("constant must be int 0..255 for integer shares")
            out[target_party] = (out[target_party] ^ constant)
            return out

        raise TypeError("Unsupported share type")

    @staticmethod
    def isw_multiply(a_shares: List[int], b_shares: List[int]) -> List[int]:
        """
        ISW multiplication for Boolean shares over GF(2^8).
        Given shares of a and shares of b, produce shares with c = a*b (in GF(2^8)).
        """
        n = len(a_shares)
        if len(b_shares) != n:
            raise ValueError("share lists must have equal length")


        # r[i][j] (i < j) is fresh randomness; r[j][i] is *derived* from it.
        # The order of the XORs matters for security:  (r_ij ^ a_i b_j) ^ a_j b_i
        # i.e. the fresh mask is added to the first partial product BEFORE the
        # second partial product is added.  Computing a_i*b_j ^ a_j*b_i first would
        # create an intermediate that depends on both shares of a and of b
        # (the insecure variant discussed in the lecture / Exercise 1).
        r = [[0]*n for _ in range(n)]
        for i in range(n):
            for j in range(i+1, n):
                    r[i][j] = secrets.randbits(8)
                    t = r[i][j] ^ GF256MPC.gf256_mul(a_shares[i], b_shares[j])
                    r[j][i] = t ^ GF256MPC.gf256_mul(a_shares[j], b_shares[i])


        c_shares = [0] * n
        for i in range(n):
            c_shares[i] = GF256MPC.gf256_mul(a_shares[i], b_shares[i])
            for j in range(n):
                if j != i:
                    c_shares[i] = c_shares[i] ^ r[i][j]

        return c_shares


    # ------------------------------------------------------------------
    # Additional gadgets (Exercise 3.5)
    # ------------------------------------------------------------------
    @staticmethod
    def square_shares(shares: Sequence[int]) -> List[int]:
        """
        Share-wise squaring.  In characteristic 2 the Frobenius map x -> x^2 is
        GF(2)-linear: (x_1 ^ ... ^ x_n)^2 = x_1^2 ^ ... ^ x_n^2.  Hence the shares of
        a^2 are the squares of the shares of a: no communication, no fresh
        randomness, n cheap operations (a linear 8x8 bit map / one table).
        """
        if not all(GF256MPC._is_byte_value(s) for s in shares):
            raise TypeError("All shares must be ints in 0..255")
        return [GF256MPC.gf256_mul(s, s) for s in shares]

    @staticmethod
    def refresh(shares: Sequence[int]) -> List[int]:
        """
        Re-randomise a sharing without changing the secret: add a fresh sharing of 0.
        For every pair i<j draw a fresh byte r and XOR it into shares i and j
        (n(n-1)/2 fresh bytes).  Needed before an ISW multiplication whenever the two
        operands are *not* independently shared (e.g. a and a^2 computed from the
        same shares); see the report, Exercise 3.5.
        """
        n = len(shares)
        out = list(shares)
        for i in range(n):
            for j in range(i + 1, n):
                r = secrets.randbits(8)
                out[i] ^= r
                out[j] ^= r
        return out

    @staticmethod
    def shared_a2_plus_ab(a_shares: List[int], b_shares: List[int],
                          refresh_b: bool = True) -> List[int]:
        """
        Shares of a^2 + a*b (all in GF(2^8)), computed without ever recombining.
          * a^2    : share-wise squaring (linear -> free, no randomness)
          * a*b    : one ISW multiplication (the only non-linear step)
          * a^2+ab : local share-wise XOR
        refresh_b=True re-randomises the shares of b before the multiplication so
        that the call is safe even if b was derived from a (e.g. b = a^2 as in the
        AES S-box).  Set refresh_b=False only if b was shared independently of a.
        """
        if len(a_shares) != len(b_shares):
            raise ValueError("share lists must have equal length")
        b_in = GF256MPC.refresh(b_shares) if refresh_b else list(b_shares)
        ab = GF256MPC.isw_multiply(a_shares, b_in)
        a2 = GF256MPC.square_shares(a_shares)
        return GF256MPC.add(a2, ab)

    @staticmethod
    def shared_a2_plus_ab_single_mult(a_shares: List[int], b_shares: List[int]) -> List[int]:
        """
        Variant: a^2 + a*b = a*(a + b)  (distributivity, char. 2).
        One local XOR of the shares + ONE ISW multiplication; no squaring needed.
        The operands a and (a+b) are only independently shared if b was shared
        independently of a -- so this variant is for independent sharings only.
        """
        s = GF256MPC.add(a_shares, b_shares)
        return GF256MPC.isw_multiply(a_shares, s)

    @staticmethod
    def shared_a_plus_ab(a_shares: List[int], b_shares: List[int],
                         refresh_b: bool = True) -> List[int]:
        """a + a*b  (the expression in the comment at the bottom of the original
        self-test; the lab sheet itself asks for a^2 + a*b)."""
        b_in = GF256MPC.refresh(b_shares) if refresh_b else list(b_shares)
        return GF256MPC.add(list(a_shares), GF256MPC.isw_multiply(a_shares, b_in))


def Shared_AddRoundKey(state: list, rk: list, num_shares: int) -> list:
    """
    AddRoundKey on Boolean-shared data (textbook version, as asked in Ex. 3.4):
      1. share every state byte and every round-key byte into num_shares shares
      2. add the two sharings share-wise (local XOR, no communication needed)
      3. reconstruct the result
    """
    res = [0] * 16
    for i in range(16):
        # Share out state and key state
        s_sh = GF256MPC.share(state[i], num_shares)
        k_sh = GF256MPC.share(rk[i], num_shares)
        # Perform AddRoundKey (share-wise XOR)
        r_sh = GF256MPC.add(s_sh, k_sh)
        # Reconstruct
        res[i] = GF256MPC.reconstruct(r_sh)
    return res


def Shared_AddRoundKey_masked(state_shares: list, rk_shares: list) -> list:
    """
    What one would actually do: state and round key STAY shared (list of 16 byte
    sharings each); AddRoundKey is linear, so it is 16 local share-wise XORs and the
    output is again a sharing (no reconstruction, no re-sharing).
    """
    return [GF256MPC.add(state_shares[i], rk_shares[i]) for i in range(16)]


def Shared_AddRoundKey_public_state(plain: list, rk_shares: list) -> list:
    """
    First round: the plaintext is public, only the key is secret.  Then no sharing of
    the plaintext is needed at all: add the plaintext byte as a *constant* to one share
    of the (shared) key byte (add_constant).  Result: a sharing of plain ^ key.
    """
    return [GF256MPC.add_constant(rk_shares[i], plain[i], 0) for i in range(16)]

def AddRoundKey(state:list, rk:list) -> list:
    s = [0] * 16
    for i in range(16):
        s[i] = state[i] ^ rk[i]
    return s
# -----------------------
# Quick self-test / example
# -----------------------
if __name__ == "__main__":
    # share and reconstruct
    n = 2
    secret_byte = 0x7A  # 122
    shares = GF256MPC.share(secret_byte, n)
    print("byte shares:", (shares))
    rec = GF256MPC.reconstruct(shares)
    assert rec == secret_byte
    print("reconstructed byte:", hex(rec))

    # add two shared integers
    x = 0x12
    y = 0x34
    sx = GF256MPC.share(x, n)
    sy = GF256MPC.share(y, n)
    sz = GF256MPC.add(sx, sy)               # local XOR of shares
    assert GF256MPC.reconstruct(sz) == (x ^ y)
    print("byte addition OK:", hex(GF256MPC.reconstruct(sz)))

    # multiply two integers
    x = 0x02  # choose any numbers between  0...255
    y = 0x83

    z = GF256MPC.gf256_mul(x,y)
    # check against Galois package to be sure
    GF = galois.GF(2 ** 8, irreducible_poly="x^8 + x^4 + x^3 + x + 1", repr="int")
    xgf = GF(x)
    ygf = GF(y)
    zgf = xgf*ygf
    assert z == int(zgf)   # own gf256_mul agrees with galois

    # now perform shared multiplication
    xs = [232, 234] #GF256MPC.share(x, n)
    ys = [48, 179] #GF256MPC.share(y, n)
    zs = GF256MPC.isw_multiply(xs, ys)

    x_val = GF256MPC.reconstruct(xs)
    y_val = GF256MPC.reconstruct(ys)
    z_val = GF256MPC.reconstruct(zs)

    expected = GF256MPC.gf256_mul(x_val, y_val)
    print(f"x={x_val:02x}, y={y_val:02x}, x*y={expected:02x}, reconstructed={z_val:02x}")
    assert z_val == expected
    print("ISW multiplication OK", hex(expected))

    # Implement shared AddRoundKey
    TEST_VECTOR_KEY_128 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf,
                           0x4f, 0x3c]
    TEST_VECTOR_PLAIN_128 = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07,
                             0x34]


    testARK = Shared_AddRoundKey(TEST_VECTOR_KEY_128, TEST_VECTOR_PLAIN_128, 2)
    ARK = AddRoundKey(TEST_VECTOR_KEY_128, TEST_VECTOR_PLAIN_128)
    assert testARK == ARK
    print("Shared AddRoundKey OK")

    # Shared computation of a^2 + a*b (lab sheet, Ex. 3.5) verified against the Galois library
    GF = galois.GF(2 ** 8, irreducible_poly="x^8 + x^4 + x^3 + x + 1", repr="int")
    import random
    for n_sh in (2, 3, 4, 5):
        for _ in range(2000):
            a, b = random.randrange(256), random.randrange(256)
            ref = int(GF(a) ** 2 + GF(a) * GF(b))
            # independent sharings of a and b
            sa, sb = GF256MPC.share(a, n_sh), GF256MPC.share(b, n_sh)
            assert GF256MPC.reconstruct(GF256MPC.shared_a2_plus_ab(sa, sb)) == ref
            assert GF256MPC.reconstruct(GF256MPC.shared_a2_plus_ab(sa, sb, refresh_b=False)) == ref
            assert GF256MPC.reconstruct(GF256MPC.shared_a2_plus_ab_single_mult(sa, sb)) == ref
            # dependent operands: b = a^2 derived share-wise from the shares of a
            sb_dep = GF256MPC.square_shares(sa)
            ref_dep = int(GF(a) ** 2 + GF(a) * GF(a) ** 2)
            assert GF256MPC.reconstruct(GF256MPC.shared_a2_plus_ab(sa, sb_dep)) == ref_dep
            # a + a*b
            ref3 = int(GF(a) + GF(a) * GF(b))
            assert GF256MPC.reconstruct(GF256MPC.shared_a_plus_ab(sa, sb)) == ref3
    print("Shared a^2 + a*b OK (n = 2..5, 8000 random tests each variant, verified vs galois)")

    # ISW: randomised check against galois for several share counts
    for n_sh in (2, 3, 4, 5, 8):
        for _ in range(2000):
            a, b = random.randrange(256), random.randrange(256)
            zs = GF256MPC.isw_multiply(GF256MPC.share(a, n_sh), GF256MPC.share(b, n_sh))
            assert GF256MPC.reconstruct(zs) == int(GF(a) * GF(b))
    # gf256_mul vs galois, exhaustive
    assert all(GF256MPC.gf256_mul(x, y) == int(GF(x) * GF(y)) for x in range(256) for y in range(256))
    print("ISW multiplication and gf256_mul verified against galois")


